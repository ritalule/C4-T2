library(RMySQL)
library(dplyr)
library(lubridate)
library(tidyverse)
library(openxlsx)
library(knitr)
library(ggplot2)
library(plotly)
library(ggthemes)
library(scales)
library(imputeTS)
library(DBI)


install.packages("forecast")
install.packages("zoo")
install.packages("timeDate")
library(timeDate)
library(forecast)

save.image()

## Create a database connection 
con = dbConnect(MySQL(), user='deepAnalytics', 
                password='Sqltask1234!', dbname='dataanalytics2018', 
                host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')

## List the tables contained in the database
dbListTables(con)

## Lists attributes contained in a table
dbListFields(con,'yr_2006')

## Lists attributes contained in a table
dbListFields(con,'iris')

## Use asterisk to specify all attributes for download
iris <- dbGetQuery(con, "SELECT * FROM iris")

## Use attribute names to specify specific attributes for download
irisSELECT <- dbGetQuery(con, "SELECT SepalLengthCm, SepalWidthCm FROM iris")

str(irisSELECT)

summary(irisSELECT) 

head(irisSELECT)  

## Select attributes needed for analysis
yr_2006 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2006')
yr_2007 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2007')
yr_2008 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2008')
yr_2009 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2009')
yr_2010 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 FROM yr_2010')

## check structure
str(yr_2006)  
str(yr_2007)  
str(yr_2008)   
str(yr_2009) 
str(yr_2010)

## Combine tables into one dataframe using dplyr
subMeters <- bind_rows(yr_2007, yr_2008, yr_2009)
str(subMeters)

head(subMeters)


## combine Date and Time attributes into a new attribute column
subMeters <- cbind(subMeters, paste(subMeters$Date, subMeters$Time), stringsAsFactors = FALSE)


## change column name
colnames(subMeters)[6] <- 'DateTime'
## Give the new attribute in the 6th column a header name 

## check structure
str(subMeters)

## convert DateTime from character to POSIXct (number of seconds since January 1, 1970)
subMeters$DateTime <- as.POSIXct(subMeters$DateTime, '%Y/%m/%d %H:%M:%S')

## add time zone from France
attr(subMeters$DateTime, 'tzone') <- 'Europe/Paris'

str(subMeters)

## lubridate to create new attributes from 'DateTime' for analysis
subMeters$year <- year(subMeters$DateTime)
subMeters$quarter <- quarter(subMeters$DateTime)
subMeters$month <- month(subMeters$DateTime)
subMeters$week <- isoweek(subMeters$DateTime)
subMeters$wday <- wday(subMeters$DateTime)
subMeters$day <- day(subMeters$DateTime)
subMeters$hour <- hour(subMeters$DateTime)
subMeters$minute <- minute(subMeters$DateTime)

str(subMeters)

##Check for missing data
## group by date, obtain the count, and turn into data frame
missing_datetime <- subMeters %>% count(Date)
incomplete_data <- data.frame(table(missing_datetime$n))
incomplete_data

## filter for all days that do not have 1440 hours
missing_time <- missing_datetime %>% filter(n !=1440) 
missing_time

## change name of certain columns
subMeters <- subMeters %>% rename(sub1 = Sub_metering_1)
subMeters <- subMeters %>% rename(sub2 = Sub_metering_2)
subMeters <- subMeters %>% rename(sub3 = Sub_metering_3)
### Viewing summary statistics
sum(subMeters$sub1)

sum(subMeters$sub2) 

sum(subMeters$sub3) 

summary(subMeters)

plot(subMeters$sub1)

## Subset the second week of 2008 - All Observations
houseWeek <- filter(subMeters, year == 2008 & week == 2)
## Plot subset houseWeek
plot(houseWeek$sub1)


## Subset the 9th day of January 2008 - All observations
houseDay <- filter(subMeters, year == 2008 & month == 1)
## Plot sub-meter 1
plot_ly(houseDay, x = ~houseDay$DateTime, y = ~houseDay$sub1, type = 'scatter', mode = 'lines')

## Subset the second week of 2008 - All Observations
housetime <- filter(subMeters, year == 2008 & week == 2 & day == 10)
## Plot subset houseWeek
plot(housetime$sub1)

save.image()

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
plot_ly(housetime, x = ~housetime$DateTime, y = ~housetime$sub1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~housetime$sub2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~housetime$sub3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))


## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
plot_ly(houseDay, x = ~houseDay$DateTime, y = ~houseDay$sub1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay$sub2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay$sub3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Day"),
         yaxis = list (title = "Power (watt-hours)"))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - All observations 
plot_ly(houseWeek, x = ~houseWeek$DateTime, y = ~houseWeek$sub1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek$sub2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek$sub3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "week"),
         yaxis = list (title = "Power (watt-hours)"))

## Subset the 9th day of January 2008 - 10 Minute frequency
houseDay10 <- filter(subMeters, year == 2008 & month == 1 & day == 9 & (minute == 0 | minute == 10 | minute == 20 | minute == 30 | minute == 40 | minute == 50))

## Plot sub-meter 1, 2 and 3 with title, legend and labels - 10 Minute frequency
plot_ly(houseDay10, x = ~houseDay10$Time, y = ~houseDay10$sub1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseDay10$sub2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseDay10$sub3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Time"),
         yaxis = list (title = "Power (watt-hours)"))

##Create a visualization with plotly for a Week of your choosing. Use all three sub-meters and make sure to label. Experiment with granularity. 
## Subset the third week of 2009 - All Observations
houseWeek1 <- filter(subMeters, year == 2009 & week == 3)

## Plot subset houseWeek
plot(houseWeek1$sub1)

plot_ly(houseWeek1, x = ~houseWeek1$DateTime, y = ~houseWeek1$sub1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseWeek1$sub2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseWeek1$sub3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "Week"),
         yaxis = list (title = "Power (watt-hours)"))

##Create a visualization for a time period of your choice. Both "Day" and "Week" highlight typical patterns in a home. 
## Subset the third week of 2009 - All Observations
houseyear <- filter(subMeters, year == 2009)
## Plot subset houseWeek
plot(houseyear$sub1)

## Plot sub-meter 1, 2 and 3 with title, legend and labels - 10 Minute frequency
plot_ly(houseyear, x = ~houseyear$DateTime, y = ~houseyear$sub1, name = 'Kitchen', type = 'scatter', mode = 'lines') %>%
  add_trace(y = ~houseyear$sub2, name = 'Laundry Room', mode = 'lines') %>%
  add_trace(y = ~houseyear$sub3, name = 'Water Heater & AC', mode = 'lines') %>%
  layout(title = "Power Consumption January 9th, 2008",
         xaxis = list(title = "year"),
         yaxis = list (title = "Power (watt-hours)"))

## Subset to one observation per week on Mondays at 8:00pm for 2007, 2008 and 2009
houseWeek <- filter(subMeters, week == 2 & hour == 20 & minute == 1)



## Create TS object with SubMeter3
tsSM3_070809weekly <- ts(house070809weekly$sub3, frequency=52, start=c(2007,1))

## Plot sub-meter 3 with autoplot (you may need to install these packages)
install.packages("ggfortify")
library(ggfortify)
autoplot(tsSM3_070809weekly)
str(subMeters)

tsSM3_070809weekly

house070809weekly

save.image()
## Plot sub-meter 3 with autoplot - add labels, color
autoplot(tsSM3_070809weekly, ts.colour = 'red', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 3")

## Plot sub-meter 3 with plot.ts
plot.ts(tsSM3_070809weekly)

##Sub-meter 1 with your choice of frequency and time period

## Create TS object with SubMeter1
TSM1 <- ts(house070809weekly$sub1, frequency=30, start=c(2007,1),
           end=c(2010,3))

## Plot sub-meter 1 with autoplot - add labels, color
autoplot(TSM1, ts.colour = 'red', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1")


## Plot sub-meter 3 with plot.ts
plot.ts(TSM1)

##Sub-meter 2 with your choice of frequency and time period

## Create TS object with SubMeter2
TSM2 <- ts(house070809weekly$sub2, frequency=60, start=c(2007,1),
           end=c(2010,3))
## Plot sub-meter 3 with plot.ts
plot.ts(TSM2)

## Plot sub-meter 2 with autoplot - add labels, color
autoplot(TSM2, ts.colour = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 2")

## Create TS object with SubMeter3
TSM3 <- ts(house070809weekly$sub3, frequency=20, start=c(2007,1),
           end=c(2010,3))
## Plot sub-meter 2 with autoplot - add labels, color
autoplot(TSM3, ts.colour = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 3")
plot.ts(TSM3)

help(forecast)
fitSM3 <- tslm(TSM3 ~ trend + season) 
summary(fitSM3)

## Create the forecast for sub-meter 3. Forecast ahead 20 time periods 
forecastfitSM3 <- forecast(fitSM3, h=20)
## Plot the forecast for sub-meter 3. 
plot(forecastfitSM3)

## Decompose Sub-meter 3 into trend, seasonal and remainder
components070809SM3weekly <- decompose(TSM3)
## Plot decomposed sub-meter 3 
plot(components070809SM3weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM3weekly)

##Sub-meter 2 decomposed plot with your choice of frequency and time period
fitSM2 <- tslm(TSM2 ~ trend + season) 
summary(fitSM2)

## Create the forecast for sub-meter 2. Forecast ahead 20 time periods 
forecastfitSM2 <- forecast(fitSM2, h=20)
## Plot the forecast for sub-meter 3. 
plot(forecastfitSM2)

## Decompose Sub-meter 2 into trend, seasonal and remainder
components070809SM2weekly <- decompose(TSM2)
## Plot decomposed sub-meter 3 
plot(components070809SM2weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM2weekly)


##Sub-meter 2 decomposed plot with your choice of frequency and time period
fitSM1 <- tslm(TSM1 ~ trend + season) 
summary(fitSM1)

## Create the forecast for sub-meter 1. Forecast ahead 20 time periods 
forecastfitSM1 <- forecast(fitSM1, h=20)
## Plot the forecast for sub-meter 3. 
plot(forecastfitSM1)

## Decompose Sub-meter 1 into trend, seasonal and remainder
components070809SM1weekly <- decompose(TSM1)
## Plot decomposed sub-meter 3 
plot(components070809SM1weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM1weekly)


## Decompose Sub-meter 2 into trend, seasonal and remainder
components070809SM2weekly <- decompose(TSM2)
## Plot decomposed sub-meter 3 
plot(components070809SM2weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM2weekly)


## Decompose Sub-meter 3 into trend, seasonal and remainder
components070809SM3weekly <- decompose(TSM3)
## Plot decomposed sub-meter 3 
plot(components070809SM3weekly)
## Check summary statistics for decomposed sub-meter 3 
summary(components070809SM3weekly)


## Seasonal adjusting sub-meter 3 by subtracting the seasonal component & plot
tsSM3_070809Adjusted <- TSM3 - components070809SM3weekly$seasonal
autoplot(tsSM3_070809Adjusted)

## Test Seasonal Adjustment by running Decompose again. Note the very, very small scale for Seasonal
plot(decompose(tsSM3_070809Adjusted))

## Holt Winters Exponential Smoothing & Plot
tsSM3_HW070809 <- HoltWinters(tsSM3_070809Adjusted, beta=FALSE, gamma=FALSE)
plot(tsSM3_HW070809, ylim = c(0, 25))

## HoltWinters forecast & plot
tsSM3_HW070809for <- forecast(tsSM3_HW070809, h=25)
plot(tsSM3_HW070809for, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 3")

## Forecast HoltWinters with diminished confidence levels
tsSM3_HW070809forC <- forecast(tsSM3_HW070809, h=25, level=c(10,25))
## Plot only the forecasted area
plot(tsSM3_HW070809forC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 3", start(2010))


## Seasonal adjusting sub-meter 2 by subtracting the seasonal component & plot
tsSM2_070809Adjusted <- TSM2 - components070809SM2weekly$seasonal
autoplot(tsSM2_070809Adjusted)

## Test Seasonal Adjustment by running Decompose again. Note the very, very small scale for Seasonal
plot(decompose(tsSM2_070809Adjusted))

## Holt Winters Exponential Smoothing & Plot
tsSM2_HW070809 <- HoltWinters(tsSM2_070809Adjusted, beta=FALSE, gamma=FALSE)
plot(tsSM2_HW070809, ylim = c(0, 25))

## HoltWinters forecast & plot
tsSM2_HW070809for <- forecast(tsSM2_HW070809, h=25)
plot(tsSM2_HW070809for, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 2")

## Forecast HoltWinters with diminished confidence levels
tsSM2_HW070809forC <- forecast(tsSM2_HW070809, h=25, level=c(10,25))
## Plot only the forecasted area
plot(tsSM2_HW070809forC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 2", start(2010))



## Seasonal adjusting sub-meter 1 by subtracting the seasonal component & plot
tsSM1_070809Adjusted <- TSM1 - components070809SM1weekly$seasonal
autoplot(tsSM1_070809Adjusted)

## Test Seasonal Adjustment by running Decompose again. Note the very, very small scale for Seasonal
plot(decompose(tsSM1_070809Adjusted))

## Holt Winters Exponential Smoothing & Plot
tsSM1_HW070809 <- HoltWinters(tsSM1_070809Adjusted, beta=FALSE, gamma=FALSE)
plot(tsSM1_HW070809, ylim = c(0, 25))

## HoltWinters forecast & plot
tsSM1_HW070809for <- forecast(tsSM1_HW070809, h=25)
plot(tsSM1_HW070809for, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 1")

## Forecast HoltWinters with diminished confidence levels
tsSM1_HW070809forC <- forecast(tsSM1_HW070809, h=25, level=c(10,25))
## Plot only the forecasted area
plot(tsSM1_HW070809forC, ylim = c(0, 20), ylab= "Watt-Hours", xlab="Time - Sub-meter 1", start(2010))

save.image()